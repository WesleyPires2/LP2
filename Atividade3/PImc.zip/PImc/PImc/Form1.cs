﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura<0)
            {
                MessageBox.Show("altura inválida");
                txtAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            mskIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso) || peso < 0)
            {
                MessageBox.Show("número inválido");
                txtPeso.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            imc = Math.Round(imc, 1);
            mskIMC.Text = imc.ToString();
            if (imc < 18.5)
                MessageBox.Show("Magreza");
            else if (imc >= 18.5 && imc < 24.9)
                MessageBox.Show("Normal");
            else if (imc >= 25 && imc < 29.9)
                MessageBox.Show("Sobrepeso");
            else if (imc >= 30 && imc < 39.9)
                MessageBox.Show("Obesidade");
            else if (imc >=40)
                MessageBox.Show("Obesidade Grave");

        }
    }
}
