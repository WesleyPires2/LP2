﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[10];
            string[] Caracter = new string[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox(($"Digite o {i + 1}º nome"), "Entrada de Dados");
                if (string.IsNullOrWhiteSpace(auxiliar))
                {
                    MessageBox.Show("nome inválido");
                    i--;
                }
                else
                {
                    Nomes[i] = auxiliar;
                    Caracter[i] = Nomes[i].Replace(" ", "");
                    double contaCaracter = 0;

                    foreach (char c in Caracter[i])
                    {
                        if (char.IsLetter(c))
                        {
                            contaCaracter++;
                        }
                    }
                    lstbxNome.Items.Add($"o nome: {Nomes[i]} tem {contaCaracter} caracteres");
                }
            }
        }
    }
}
