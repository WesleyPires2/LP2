﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

            string[,] matriz = new string[9,10];
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "E", "A", "B" };

            for (int i = 0; i<9; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    matriz[i,j] = Interaction.InputBox(($" Aluno {i+1} questão {j+1}"), "Entrada de dados").ToUpper();

                    if (matriz[i, j] == gabarito[j])
                    {
                        lstbxResposta.Items.Add($"O aluno {i+1} acertou a questão {j+1} era {gabarito[j]} escolheu {matriz[i, j]}");
                    }
                    else
                    {
                        lstbxResposta.Items.Add($"O aluno {i + 1} errou a questão {j + 1} era {gabarito[j]} escolheu {matriz[i, j]}");
                    }
                }
            }  
        }
    }
}
