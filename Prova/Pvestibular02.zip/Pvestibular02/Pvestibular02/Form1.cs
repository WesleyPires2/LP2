﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        int[,] Matriz = new int[2, 5];
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
           
            int totalGeral = 0;
            string auxiliar = "";

            for (int i = 0; i<2; i++)
            {
                int totalAlunos = 0;
                for (int j = 0; j<5; j++)
                {
                    auxiliar = Interaction.InputBox(($"Total do curso {i + 1} do Ano {j + 1}"), "Entrada de dados");
                    if (!int.TryParse(auxiliar, out Matriz[i, j]) || Matriz[i, j] < 0)
                    {
                        MessageBox.Show("Dados inválidos");
                        j--;
                    }
                    else
                    {
                        totalAlunos += Matriz[i, j];
                        lstbxVestibular.Items.Add($"Total do curso {i + 1} do Ano {j + 1}: {Matriz[i,j]}");
                    }
                }
                lstbxVestibular.Items.Add("");
                lstbxVestibular.Items.Add("-----------------------------------------------");
                lstbxVestibular.Items.Add($"Total do curso {i + 1}: {totalAlunos}");
                totalGeral += totalAlunos;
            }
            lstbxVestibular.Items.Add("");
            lstbxVestibular.Items.Add("-----------------------------------------------");
            lstbxVestibular.Items.Add($"Total Geral:{totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVestibular.Items.Clear();
        }
    }
}
