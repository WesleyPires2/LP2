﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double valA, valB, valC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out valA) || (valA == 0))
            {
                MessageBox.Show("Valor inválido");
                txtValorA.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(valB - valC) < valA && valA < (valB + valC)) &&
               (Math.Abs(valA - valC) < valB && valB < (valA + valC)) &&
               (Math.Abs(valA - valB) < valC && valC < (valA + valB)))
            {
                if ((valA == valB) && (valB == valC))
                    MessageBox.Show("Triangulo Equilatero");
                else if ((valA == valB) || (valA == valC) || (valB == valC))
                    MessageBox.Show("Triangulo Isósceles");
                else if ((valA != valB) && (valB != valC) && (valA != valC))
                    MessageBox.Show("Triangulo Escaleno");

            }
            else
                MessageBox.Show("Nao forma um triângulo");
            
        }

        private void txtValorA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valB) || (valB == 0))
            {
                MessageBox.Show("Valor inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out valC) || (valC == 0))
            {
                MessageBox.Show("Valor inválido");
                txtValorC.Focus();
            }
        }
    }
}
