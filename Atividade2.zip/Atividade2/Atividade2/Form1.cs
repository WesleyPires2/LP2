﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Número 1 inválido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out Numero2))
                {
                MessageBox.Show("Número 2 inválido");
                txtNumero2.Focus();
            }
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {

        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out Numero2) || (Numero2 == 0))
            {
                MessageBox.Show("0 é um número inválido");
                txtNumero2.Focus();
            }
            else
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
        }

        private void btnadiç_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
        }
    }
}
