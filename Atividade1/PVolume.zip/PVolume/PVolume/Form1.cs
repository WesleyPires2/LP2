﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("altura invalida");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = String.Empty;
            txtVolume.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("raio inválido");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("altura inválida");
                txtAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }
        

        private void button1_Click(object sender, EventArgs e)
        {

        }


        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("raio inválido");
            }
            /*else if (raio <= 0)
            {
                MessageBox.Show("raio deve ser maior que zero");
            }*/

        }
    }
}
